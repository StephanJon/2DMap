#include "../include/Seq2D.h"

/*
Implementation for the class Seq2D
*/


/**
* Seq2D object no-argument constructor
*/
template <typename T>
Seq2D<T>::Seq2D() {
	this->s = NULL;
	this->scale = 0;
	this->nRow = 0;
	this->nCol = 0;
}

//Constructor
template <typename T>
Seq2D<T>::Seq2D(std::vector<vector<T>> S, float scl) {
	try {
		if (scl <= 0 || S.size() == 0 || S.at(0).size() == 0)
		{
			throw invalid_argument();
		}
		for (int i = 0; i < S.size(); i++)
		{
			if (S.at(i).size() != S.at(0).size())
			{
				throw invalid_argument();
			}
		}
		this->s = S;
		this->scale = scl;
		this->nRow = S.size();
		this->nCol = S.at(0).size();
	}
	catch (const char *e) {
		cout << "Please ensure that sequence of sequence of T has rows and \
				columns greater than 0, and that the number of rows and columns \
				are the same.\n \
				Also, ensure that the scale passed is greater than 0." << endl << e;
	}

}


//Sets an entry of s to an object of T
template <typename T>
void Seq2D<T>::set(PointT p, T v) {
	try {
		if (!(validPoint(p)))
		{
			outside_bounds error;
			throw error.what();
		}
		this->s.at(p.y()).at(p.x()) = v;
	}
	catch (const char *e) {
		cout << "Point passed is invalid." << endl << e;
	}
}

//Returns an entry of s
template <typename T>
T Seq2D<T>::get(PointT p) {
	try {
		if (!(validPoint(p)))
		{
			throw outside_bounds();
		} return this->s.at(p.y()).at(p.x());
	}
	catch (const char *e) {
		cout << "Point passed is invalid." << endl << e;
	}
}

//Returns the number of rows in s
template <typename T>
int Seq2D<T>::getNumRow() { return this->nRow; }

//Returns the number of coloumns in s
template <typename T>
int Seq2D<T>::getNumCol() { return this->nCol; }

//Returns the scale of s
template <typename T>
float Seq2D<T>::getScale() { return this->scale; }

/*
Returns the number of occurences that t of Type T is
in s
*/
template <typename T>
int Seq2D<T>::count(T t) {
	int count = 0;
	for (int i = 0; i < getNumRow(); i++)
	{
		for (int j = 0; j < getNumCol; j++)
		{
			if (this->s.at(i).at(j) == t)
			{
				count++;
			}
		}
	} return count;
}

/*
Returns the number of occurences that t of Type T is
in s, specifically on a line of entries
*/
template <typename T>
int Seq2D<T>::count(LineT l, T t) {
	try {
		if (!(validLine(l)))
		{
			invalid_argument error;
			throw error.what();
		}
		int count = 0;
		std::vector<PointT> points;
		points.push_back(pointsInLine(l));
		for (int i = 0; i < points.size(); i++)
		{
			if (this->s.at(points.at(i).y()).at(points.at(i).x()) == t)
			{
				count++;
			}
		} return count;
	}
	catch (const char *e) {
		cout << "One or more points on the line passed are invalid." << endl << e;
	}
}

/*
Returns the number of occurences that t of Type T is
in s, specifically on a path of entries
*/
template <typename T>
int Seq2D<T>::count(PathT pth, T t) {
	try {
		if (!(validPath(pth)))
		{
			invalid_argument error;
			throw error.what();
		}
		int count = 0;
		std::vector<LineT> temp;
		temp.push_back(pth.getS());
		for (int i = 0; i < pth.size(); i++)
		{
			count += count(temp.at(i), t);
		} return count;
	}
	catch (const char *e) {
		cout << "One or more points on the path passed are invalid." << endl << e;
	}
}

//Returns the length of a path on the map by its scale
template <typename T>
int Seq2D<T>::length(PathT pth) {
	try {
		if (!(validPath(pth)))
		{
			invalid_argument error;
			throw error.what();
		} return pth.len()*getScale();
	}
	catch (const char *e) {
		cout << "One or more points on the path passed are invalid." << endl << e;
	}
}

/*
Return true if a path exists between p1 and p2 with all of the points
on the path being of the same value
*/
template <typename T>
bool Seq2D<T>::connected(PointT p1, PointT p2) {
	try {
		if (!(validPoint(p1)) || !(validPoint(p2)))
		{
			invalid_argument error;
			throw error.what();
		}
		std::vector<std::vector<bool>> marked;
		for (int i = 0; i < getNumRow; i++)
		{
			for (int j = 0; j < getNumCol; j++)
			{
				marked.at(i).at(j).push_back(false)
			}
		}

		bool check = false;
		if (p1.x() == p2.x() && p1.y() == p2.y())
		{
			return true;
		}
		PointT Np1 = p1.translate(0, 1);
		PointT Sp1 = p1.translate(0, -1);
		PointT Wp1 = p1.translate(-1, 0);
		PointT Ep1 = p1.translate(1, 0);
		if (validPoint(Np1) && !check) {
			if (this->get(Np1) == this->get(p2)) {
				marked[Np1.y()][Np1.x()] = true;
				check = connectedMarked(Np1, p2, marked);
			}
		}
		if (validPoint(Sp1) && !check) {
			if (this->get(Sp1) == this->get(p2)) {
				marked[Sp1.y()][Sp1.x()] = true;
				check = connectedMarked(Sp1, p2, marked);
			}
		}
		if (validPoint(Wp1) && !check) {
			if (this->get(Wp1) == this->get(p2)) {
				marked[Wp1.y()][Wp1.x()] = true;
				check = connectedMarked(Wp1, p2, marked);
			}
		}
		if (validPoint(Ep1) && !check) {
			if (this->get(Ep1) == this->get(p2)) {
				marked[Ep1.y()][Ep1.x()] = true;
				check = connectedMarked(Sp1, p2, marked);
			}
		}
		if (check) {
			return check;
		} return false;
	}
	catch (const char *e) {
		cout << "Point 1 or 2 are invalid points." << endl << e;
	}
	
}

/*
Helper function for connected
*/
template <typename T>
bool Seq2D<T>::connectedMarked(PointT p1, PointT p2, std::vector<std::vector<bool>> marked) {
	try {
		if (!(validPoint(p1)) || !(validPoint(p2)))
		{
			invalid_argument error;
			throw error.what();
		}
		bool check = false;
		if (p1.x() == p2.x() && p1.y() == p2.y())
		{
			return true;
		}
		PointT Np1 = p1.translate(0, 1);
		PointT Sp1 = p1.translate(0, -1);
		PointT Wp1 = p1.translate(-1, 0);
		PointT Ep1 = p1.translate(1, 0);
		if (validPoint(Np1) && !marked.at(p1.y()).at(p1.x()) && !check) {
			if (this->get(Np1) == this->get(p2)) {
				marked[Np1.y()][Np1.x()] = true;
				check = connectedMarked(Np1, p2, marked);
			}
		}
		if (validPoint(Sp1) && !marked.at(p1.y()).at(p1.x()) && !check) {
			if (this->get(Sp1) == this->get(p2)) {
				marked[Sp1.y()][Sp1.x()] = true;
				check = connectedMarked(Sp1, p2, marked);
			}
		}
		if (validPoint(Wp1) && !marked.at(p1.y()).at(p1.x()) && !check) {
			if (this->get(Wp1) == this->get(p2)) {
				marked[Wp1.y()][Wp1.x()] = true;
				check = connectedMarked(Wp1, p2, marked);
			}
		}
		if (validPoint(Ep1) && !marked.at(p1.y()).at(p1.x()) && !check) {
			if (this->get(Ep1) == this->get(p2)) {
				marked[Ep1.y()][Ep1.x()] = true;
				check = connectedMarked(Ep1, p2, marked);
			}
		}
		if (check) {
			return check;
		} return false;
	}
	catch (const char *e) {
		cout << "Point 1 or 2 are invalid points." << endl << e;
	}

}

/**** Local Functions ****/

//Returns true if row i exists in a 2D array
template <typename T>
bool Seq2D<T>::validRow(int i) {
	if (0 <= i && i <= this->nRow - 1)
	{
		return true;
	} return false;
}

//Returns true if column i exists in a 2D array
template <typename T>
bool Seq2D<T>::validCol(int i) {
	if (0 <= i && i <= this->nCol - 1)
	{
		return true;
	} return false;
}

//Returns true if the given point lies within the boundaries of the map
template <typename T>
bool Seq2D<T>::validPoint(PointT p) { return (validRow(p.y()) && validCol(p.x())) }

/*
Returns true if all of the points for the given line lie within the boundaries
of the map.
*/
template <typename T>
bool Seq2D<T>::validLine(LineT l) {
	std::vector<PointT> points;
	points.push_back(pointsInLine(l));
	for (int i = 0; i < points.size(); i++)
	{
		if (!(validPoint(points.at(i))))
		{
			return false;
		}
	} return true;
}

/*
Returns true if all of the points for the given path lie within the boundaries
of the map.
*/
template <typename T>
bool Seq2D<T>::validPath(PathT pth) {
	std::vector<LineT> lines;
	lines.push_back(pth.getS());
	for (int i = 0; i < lines.size(); i++)
	{
		if (!(validLine(lines.at(i))))
		{
			return false;
		}
	} return true;
}

//Returns the points of a line in a set of PointT objects
template <typename T>
std::vector<PointT> Seq2D<T>::pointsInLine(LineT l) {
	std::vector<PointT> Points;
	PointT temp = l.strt();
	Points.push_back(temp);
	if (l.orient() == N) {
		for (int i = 0; i < l.len(); i++) {
			temp = temp.translate(0, 1);
			Points.push_back(temp);
		}
	}
	else if (l.orient() == S) {
		for (int i = 0; i < l.len(); i++) {
			temp = temp.translate(0, -1);
			Points.push_back(temp);
		}
	}
	else if (l.orient() == E) {
		for (int i = 0; i < l.len(); i++) {
			temp = temp.translate(1, 0);
			Points.push_back(temp);
		}
	}
	else {
		for (int i = 0; i < l.len(); i++) {
			temp = temp.translate(-1, 0);
			Points.push_back(temp);
		}
	}
	return Points;
}

//Returns The set of points that make up the input path
template <typename T>
std::vector<PointT> Seq2D::pointsInPath(PathT pth) {
	std::vector<PointT> Points;
	std::vector<LineT> lines;
	lines.push_back(pth.getS());
	for (int i = 0; i < lines.size(); i++)
	{
		Points.push_back(pointsInLine(lines.at(i)));
	} return Points;
}




